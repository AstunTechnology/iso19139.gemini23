
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)


**************************

Package gmd from Eden repository (http://eden.ign.fr/xsd) 2008-06-26 full release of ISO/TC211 schemas without any modification