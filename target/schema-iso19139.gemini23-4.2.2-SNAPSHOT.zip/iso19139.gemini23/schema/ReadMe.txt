
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)

Includes following packages:

.gco (ISO 19103 concepts);
.gmx (ISO 19139 concepts);
.gmd (ISO 19115 concepts);
.gmi (ISO 19115-2 concepts);
.gml (ISO 19136 concepts);
.gsr (ISO 19111 concepts); 
.gss (ISO 19107 concepts);
.gts (ISO 19108 concepts);
.srv (ISO 19119 concepts);
.resources (Codelist, crs, example, uom)

See X\ReadMe.txt for details of lineage and modification of the package X